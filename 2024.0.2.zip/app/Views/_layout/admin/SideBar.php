<?php
$uri = current_url(true);
$segments = $uri->getSegments(); ?>
<aside id="sidebar-wrapper" class="d-print-none">
    <div class="sidebar-brand">
        <a href="<?= base_url('/' . bin2hex('admin') . '/' . bin2hex('home')) ?>">
            <img alt="image" src="<?= base_url() ?>/public/assets/img/logo.png" class="header-logo"
                style="margin-top: -5px;" />
            <span class="logo-name" style="margin-top: 20px;">PRESENSI</span>
        </a>
    </div>
    <ul class="sidebar-menu">
        <li class="menu-header">Main</li>
        <li class="dropdown <?php if ($segments[0] === bin2hex('admin') && $segments[1] === bin2hex('home')) {
            echo "active";
        } ?>">
            <a href="<?= base_url('/' . bin2hex('admin') . '/' . bin2hex('home')) ?>" class="nav-link"><i
                    data-feather="monitor"></i><span>Dashboard</span></a>
        </li>
        <li class="dropdown <?php if ($segments[0] === bin2hex('admin') && ($segments[1] === bin2hex('presensi') || $segments[1] === bin2hex('rekap-presensi'))) {
            echo "active";
        } ?>">
            <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="list"></i><span>Presensi</span></a>
            <ul class="dropdown-menu">
                <li class="<?php if ($segments[0] === bin2hex('admin') && $segments[1] === bin2hex('presensi')) {
                    echo "active";
                } ?>"><a class="nav-link"
                        href="<?= base_url('/' . bin2hex('admin') . '/' . bin2hex('presensi')) ?>">Hari ini</a></li>
                <li class="<?php if ($segments[0] === bin2hex('admin') && $segments[1] === bin2hex('rekap-presensi')) {
                    echo "active";
                } ?>"><a class="nav-link"
                        href="<?= base_url('/' . bin2hex('admin') . '/' . bin2hex('rekap-presensi')) ?>">Rekap
                        Presensi</a></li>
            </ul>
        </li>
        <li class="menu-header">Data Master</li>
        <li class="dropdown <?php if ($segments[0] === bin2hex('admin') && ($segments[1] === bin2hex('data-periode'))) {
            echo "active";
        } ?>">
            <a href="<?= base_url('/' . bin2hex('admin') . '/' . bin2hex('data-periode')) ?>" class="nav-link">
                <i data-feather="check-circle"></i><span>Data Periode</span>
            </a>
        </li>
        <li class="dropdown <?php if ($segments[0] === bin2hex('admin') && ($segments[1] === bin2hex('data-guru'))) {
            echo "active";
        } ?>">
            <a href="<?= base_url('/' . bin2hex('admin') . '/' . bin2hex('data-guru')) ?>" class="nav-link">
                <i data-feather="book"></i><span>Data Guru</span>
            </a>
        </li>
        <li class="dropdown <?php if ($segments[0] === bin2hex('admin') && ($segments[1] === bin2hex('data-siswa'))) {
            echo "active";
        } ?>">
            <a href="<?= base_url('/' . bin2hex('admin') . '/' . bin2hex('data-siswa')) ?>" class="nav-link">
                <i data-feather="users"></i><span> Data Peserta Didik</span>
            </a>
        </li>

        <li class="dropdown <?php if ($segments[0] === bin2hex('admin') && ($segments[1] === bin2hex('data-kelas') || $segments[1] === bin2hex('data-siswa-kelas'))) {
            echo "active";
        } ?>">
            <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="home"></i><span>Data
                    Rombel</span></a>
            <ul class="dropdown-menu">
                <li class="<?php if ($segments[0] === bin2hex('admin') && $segments[1] === bin2hex('data-kelas')) {
                    echo "active";
                } ?>"><a class="nav-link"
                        href="<?= base_url('/' . bin2hex('admin') . '/' . bin2hex('data-kelas')) ?>">Wali Kelas</a></li>
                <li class="<?php if ($segments[0] === bin2hex('admin') && $segments[1] === bin2hex('data-siswa-kelas')) {
                    echo "active";
                } ?>"><a class="nav-link"
                        href="<?= base_url('/' . bin2hex('admin') . '/' . bin2hex('data-siswa-kelas')) ?>">Anggota
                        Rombel</a></li>
            </ul>
        </li>
        <li class="dropdown <?php if ($segments[0] === bin2hex('admin') && ($segments[1] === bin2hex('data-presensi'))) {
            echo "active";
        } ?>">
            <a href="<?= base_url('/' . bin2hex('admin') . '/' . bin2hex('data-presensi')) ?>" class="nav-link">
                <i data-feather="book-open"></i><span>Data Presensi</span>
            </a>
        </li>
        <li class="menu-header">Pengaturan</li>
        <li class="dropdown <?php if ($segments[0] === bin2hex('admin') && ($segments[1] === bin2hex('hari-libur'))) {
            echo "active";
        } ?>">
            <a href="<?= base_url('/' . bin2hex('admin') . '/' . bin2hex('hari-libur')) ?>" class="nav-link">
                <i data-feather="calendar"></i><span>Hari Libur Nasional</span>
            </a>
        </li>
        <li class="dropdown <?php if ($segments[0] === bin2hex('admin') && ($segments[1] === bin2hex('pembaruan'))) {
            echo "active";
        } ?>">
            <a href="<?= base_url('/' . bin2hex('admin') . '/' . bin2hex('pembaruan')) ?>" class="nav-link">
                <i data-feather="download"></i><span>Pembaruan</span>
            </a>
        </li>
        <li class="dropdown <?php if ($segments[0] === bin2hex('admin') && ($segments[1] === bin2hex('sinkron'))) {
            echo "active";
        } ?>">
            <a href="<?= base_url('/' . bin2hex('admin') . '/' . bin2hex('sinkron')) ?>" class="nav-link">
                <i data-feather="github"></i><span>Sinkron File</span>
            </a>
        </li>
    </ul>
</aside>